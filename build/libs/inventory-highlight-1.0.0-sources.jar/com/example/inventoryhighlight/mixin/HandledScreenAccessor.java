package com.example.inventoryhighlight.mixin;

import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Exposes the screen background position fields.
 * Mojang mappings rename these from x/y (Yarn) to leftPos/topPos.
 */
@Mixin(class_465.class)
public interface HandledScreenAccessor {

    @Accessor("leftPos")
    int getBackgroundX();

    @Accessor("topPos")
    int getBackgroundY();

    @Accessor("hoveredSlot")
    net.minecraft.class_1735 getHoveredSlot();
}
