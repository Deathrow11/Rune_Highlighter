package com.example.inventoryhighlight;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class ConfigScreen extends class_437 {

    private final class_437 parent;
    private boolean draftEnabled;
    private HighlightColor draftColor;
    private HighlightMode draftMode;
    private String draftSearch;

    private class_4185 enableButton;
    private class_4185 colorButton;
    private class_4185 modeButton;
    private class_342 searchBox;

    public ConfigScreen(class_437 parent) {
        super(class_2561.method_43471("config.inventoryhighlight.title"));
        this.parent = parent;
        this.draftEnabled = ModConfig.INSTANCE.enabled;
        this.draftColor = ModConfig.INSTANCE.highlightColor;
        this.draftMode = ModConfig.INSTANCE.highlightMode;
        this.draftSearch = ModConfig.INSTANCE.searchFilter;
    }

    @Override
    protected void method_25426() {
        int centerX = field_22789 / 2;
        int y = field_22790 / 4 + 10;
        y += 30;

        // Toggle enable/disable
        enableButton = class_4185.method_46430(getEnableLabel(), button -> {
            draftEnabled = !draftEnabled;
            button.method_25355(getEnableLabel());
        }).method_46434(centerX - 100, y, 200, 20).method_46431();
        method_37063(enableButton);
        y += 30;

        // Cycle highlight color
        colorButton = class_4185.method_46430(getColorLabel(), button -> {
            HighlightColor[] colors = HighlightColor.values();
            int next = (draftColor.ordinal() + 1) % colors.length;
            draftColor = colors[next];
            button.method_25355(getColorLabel());
        }).method_46434(centerX - 100, y, 200, 20).method_46431();
        method_37063(colorButton);
        y += 30;

        // Cycle highlight mode
        modeButton = class_4185.method_46430(getModeLabel(), button -> {
            HighlightMode[] modes = HighlightMode.values();
            int next = (draftMode.ordinal() + 1) % modes.length;
            draftMode = modes[next];
            button.method_25355(getModeLabel());
        }).method_46434(centerX - 100, y, 200, 20).method_46431();
        method_37063(modeButton);
        y += 40;

        // Save / Cancel
        method_37063(class_4185.method_46430(
                class_2561.method_43471("config.inventoryhighlight.save"),
                button -> save()).method_46434(centerX - 100, y, 98, 20).method_46431());

        method_37063(class_4185.method_46430(
                class_2561.method_43471("config.inventoryhighlight.cancel"),
                button -> method_25419()).method_46434(centerX + 2, y, 98, 20).method_46431());
    }

    private class_2561 getEnableLabel() {
        return class_2561.method_43471(
                draftEnabled
                        ? "config.inventoryhighlight.enable_on"
                        : "config.inventoryhighlight.enable_off");
    }

    private class_2561 getColorLabel() {
        return class_2561.method_43469("config.inventoryhighlight.color", draftColor.displayName);
    }

    private class_2561 getModeLabel() {
        return class_2561.method_43469("config.inventoryhighlight.mode", draftMode.displayName);
    }

    private void save() {
        ModConfig.INSTANCE.enabled = draftEnabled;
        ModConfig.INSTANCE.highlightColor = draftColor;
        ModConfig.INSTANCE.highlightMode = draftMode;
        ModConfig.INSTANCE.searchFilter = draftSearch.trim();
        ModConfig.save();

        if (field_22787 != null && field_22787.field_1724 != null) {
            field_22787.field_1724.method_7353(
                    class_2561.method_43471("config.inventoryhighlight.saved"),
                    false);
        }
        method_25419();
    }

    @Override
    public void method_25419() {
        if (field_22787 != null) {
            field_22787.method_1507(parent);
        }
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(graphics, mouseX, mouseY, partialTick);
        graphics.method_27534(
                field_22793,
                class_2561.method_43471("config.inventoryhighlight.description"),
                field_22789 / 2,
                field_22790 / 4 - 12,
                0xA0A0A0);
    }
}