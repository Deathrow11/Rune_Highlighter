package com.example.inventoryhighlight;

import java.util.Locale;
import net.minecraft.class_124;
import net.minecraft.class_1799;

public final class HighlightHelper {

    private HighlightHelper() {}

    public static boolean shouldHighlight(class_1799 stack) {
        if (!ModConfig.INSTANCE.enabled || stack.method_7960()) {
            return false;
        }

        String name = class_124.method_539(stack.method_7964().getString())
                .trim()
                .toUpperCase(Locale.ROOT);
        if (name.isEmpty()) {
            return false;
        }

        String filter = ModConfig.INSTANCE.searchFilter.trim().toLowerCase(Locale.ROOT);

        for (String rune : HighlightNames.NAMES) {
            if (!filter.isEmpty() && !rune.toLowerCase(Locale.ROOT).contains(filter)) {
                continue;
            }
            if (name.contains(rune)) {
                return true;
            }
        }
        return false;
    }
}
