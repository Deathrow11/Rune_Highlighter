package com.example.inventoryhighlight;

import java.util.Locale;
import java.util.Set;
import net.minecraft.class_124;
import net.minecraft.class_1799;

public final class HighlightHelper {

    private HighlightHelper() {}

    public static boolean shouldHighlight(class_1799 stack) {
        if (!ModConfig.INSTANCE.enabled || stack.method_7960()) {
            return false;
        }

        String name = class_124.method_539(stack.method_7964().getString())
                .trim()
                .toUpperCase(Locale.ROOT);
        if (name.isEmpty()) {
            return false;
        }

        String filter = ModConfig.INSTANCE.searchFilter.trim().toLowerCase(Locale.ROOT);
        Set<String> names = namesForMode(ModConfig.INSTANCE.highlightMode);

        for (String rune : names) {
            if (!filter.isEmpty() && !rune.toLowerCase(Locale.ROOT).contains(filter)) {
                continue;
            }
            if (name.contains(rune)) {
                return true;
            }
        }
        return false;
    }

    private static Set<String> namesForMode(HighlightMode mode) {
        return switch (mode) {
            case STRICT    -> StrictHighlightNames.NAMES;
            case LOW_LEVEL -> LowLevelHighlightNames.NAMES;
            default        -> NormalHighlightNames.NAMES;
        };
    }
}