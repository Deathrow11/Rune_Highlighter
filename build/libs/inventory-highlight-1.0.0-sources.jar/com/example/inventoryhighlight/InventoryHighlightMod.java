package com.example.inventoryhighlight;

import com.example.inventoryhighlight.mixin.HandledScreenAccessor;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.class_1735;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.minecraft.class_465;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class InventoryHighlightMod implements ClientModInitializer {

    public static final String MOD_ID = "inventoryhighlight";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    /** Default H — press to toggle, hold Shift while pressing to open config */
    public static class_304 toggleKey;

    @Override
    public void onInitializeClient() {
        ModConfig.load();
        LOGGER.info("InventoryHighlight initialized (enabled={})", ModConfig.INSTANCE.enabled);

        toggleKey = KeyBindingHelper.registerKeyBinding(
                new class_304(
                        "key.inventoryhighlight.toggle",
                        class_3675.class_307.field_1668,
                        GLFW.GLFW_KEY_H,
                        class_304.class_11900.method_74698(
                                class_2960.method_60655(MOD_ID, MOD_ID))
                )
        );

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.method_1436()) {
                if (client.method_74187()) {
                    client.method_1507(new ConfigScreen(client.field_1755));
                    return;
                }

                ModConfig.INSTANCE.enabled = !ModConfig.INSTANCE.enabled;
                ModConfig.save();

                if (client.field_1724 != null) {
                    client.field_1724.method_7353(
                            class_2561.method_43471(
                                    ModConfig.INSTANCE.enabled
                                            ? "message.inventoryhighlight.enabled"
                                            : "message.inventoryhighlight.disabled"),
                            false);
                }
            }
        });

        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (!(screen instanceof class_465<?> containerScreen)) {
                return;
            }

            ScreenEvents.afterRender(screen).register((s, graphics, mouseX, mouseY, tickDelta) -> {
                if (!ModConfig.INSTANCE.enabled) {
                    return;
                }

                HandledScreenAccessor accessor = (HandledScreenAccessor) s;
                int bgX = accessor.getBackgroundX();
                int bgY = accessor.getBackgroundY();

                for (class_1735 slot : containerScreen.method_17577().field_7761) {
                    if (!slot.method_7681() || !HighlightHelper.shouldHighlight(slot.method_7677())) {
                        continue;
                    }

                    int sx = bgX + slot.field_7873;
                    int sy = bgY + slot.field_7872;
                    graphics.method_25294(sx, sy, sx + 16, sy + 16, ModConfig.INSTANCE.highlightColor.argb);
                }
            });
        });
    }
}
